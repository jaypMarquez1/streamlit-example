# Frosty: Build a LLM Chatbot in Streamlit on your Snowflake Data

## Overview

In this guide, we will build an LLM-powered chatbot named "Frosty" that performs data exploration and question answering by writing and executing SQL queries on Snowflake data. The application uses Streamlit and Snowflake and can be plugged into your LLM of choice, alongside data from Snowflake Marketplace. By the end of the session, you will have an interactive web application chatbot which can converse and answer questions based on a public job listings dataset.

**View the [demo page](https://developers.snowflake.com/demos/data-exploration-llm-chatbot/) for a full walkthrough and more material.**

## Run the app

Once environment is set up and secrets are configured including connection to a Snowflake environment with the relevant view, the app can be run by:

```sh
streamlit run src/frosty_app.py
```

![App Demo](./assets/App_Demo.gif)

## Deployment Diagram

![Deployment Diagram](./assets/frosty-diagram.png)